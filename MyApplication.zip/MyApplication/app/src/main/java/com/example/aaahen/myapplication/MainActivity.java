package com.example.aaahen.myapplication;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ArrayList<String> menulists;
    private ArrayAdapter<String> adapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private String mTitle;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTitle = (String) getTitle();

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);
        menulists = new ArrayList<>();
        for (int i=0;i<5;i++)
            menulists.add("深圳大学0"+i);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,menulists);
        mDrawerList.setAdapter(adapter);
        mDrawerList.setOnItemClickListener(this);

//        Toolbar t = (Toolbar) findViewById(R.drawable.rc_ll);
//        Toolbar t = (Toolbar) findViewById();
        mDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.draw_open,R.string.draw_close){
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
//                System.out.println(getActionBar().getTitle().toString());
               getSupportActionBar().setTitle("niam");
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getSupportActionBar().setTitle(mTitle);
            }
        };
        mDrawerLayout.addDrawerListener(mDrawerToggle);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //动态插入fragment到Fragmelayout中
        Fragment comtentFragment = new ContentFragment();
        Bundle args = new Bundle();
        args.putString("text", menulists.get(position));
        comtentFragment.setArguments(args);

        FragmentManager fm = getFragmentManager();
        fm.beginTransaction().replace(R.id.content_fram,comtentFragment).commit();
        mDrawerLayout.closeDrawer(mDrawerList);
    }
}
